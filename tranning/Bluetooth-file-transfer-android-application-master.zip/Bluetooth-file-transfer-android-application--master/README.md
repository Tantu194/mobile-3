# Bluetooth-file-transfer-android-application-
Any file share via Bluetooth android app in android studio

First add below permissions in AndroidManifest.xml 

[1] "android.permission.WRITE_EXTERNAL_STORAGE"              
[2] "android.permission.READ_EXTERNAL_STORAGE"                            
[3] "android.permission.BLUETOOTH"                                      
[4] "android.permission.BLUETOOTH_ADMIN"

Enjoy.... :)
Happy coding and do cool things.
